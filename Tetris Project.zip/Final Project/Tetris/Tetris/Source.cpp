#include<SFML/Graphics.hpp>
#include<SFML/System.hpp>
#include<SFML/Window.hpp>
#include<SFML/Graphics/Font.hpp>
#include <iostream>
#include <conio.h>
#include<fstream>
#include<stack>
#include <queue>
using namespace std;
const int width = 13;
const int height = 20;
const int shapesize = 4;
const char emptyspace = ' ';
const char block = '@';
class information
{
public:
    void rejisteruser()
    {
        string username;
        cout << "Enter a username: ";
        cin >> username;
        char password[20];
        int i = 0;
        char ch;
        cout << "Enter password: ";

        while ((ch = _getch()) != '\r')
        {
            if (ch == '\b')
            {
                if (i > 0)
                {
                    cout << "\b \b";
                    i--;
                }
            }
            else {
                password[i] = ch;
                cout << '*';
                i++;
            }
        }

        password[i] = '\0';
        cout << endl;
        cout << "Entered password: " << password << endl;

        ofstream file("users.dat", ios::binary);

        file << username << " " << password << endl;
        file.write(reinterpret_cast<char*>(&username), sizeof(&username));
        file.write(reinterpret_cast<char*>(&password), sizeof(&password));
        file.close();
        cout << "Registration successful." << endl;
    }
    void login()
    {
        string username, password;
        cout << "Enter your username: ";
        cin >> username;
        cout << "Enter your password: ";
        cin >> password;

        ifstream file("users.dat", ios::binary);
        string fileUsername, filePassword;

        while (file >> fileUsername >> filePassword)
        {
            if (username == fileUsername && password == filePassword)
            {
                cout << "Access granted." << endl;
                return;
            }
        }
        cout << "Access denied. Invalid username or password." << endl;
    }
    void playersname()
    {
        string player1;
        cout << "Player: ";
        cin >> player1;
        ofstream file("playernames.dat", ios::binary);
        file.write(reinterpret_cast<char*>(&player1), sizeof(&player1));
        file.close();
    }

};

class tetrisgame
{
public:
    void name()
    {
        cout << "\033[1;31m";
        cout << "\n\n\n";
        cout << "---------  --------  --------  --------   --------   --------\n";
        cout << "   ||      |-           ||     ||     ||     ||      ||\n";
        cout << "   ||      |----        ||     --------      ||      --------\n";
        cout << "   ||      |-           ||     ||   ||       ||             ||\n";
        cout << "   ||      --------     ||     ||    ||   --------   --------\n";
        cout << "\033[0m";
    }

    void details()
    {

        cout << "\n==============================================";
        cout << "\n        Details of the tetris Game";
        cout << "\n==============================================";
        cout << "\n i. tetris is a classic puzzle game.";
        cout << "\n ii. The objective is to arrange falling blocks to create complete lines.";
        cout << "\n iii. As lines are cleared, the game speed increases.";
        cout << "\n iv. The game ends when the blocks stack up and reach the top.";
    }

    void rules()
    {
        cout << "\n==============================================";
        cout << "\n        Rules for the tetris Game:";
        cout << "\n==============================================";
        cout << "\n i. Use the 'W','A','S','D' keys to move the falling block left, right, or down.";
        cout << "\n ii. Press the spacebar to rotate the falling block.";
        cout << "\n iii. Create complete lines by filling the entire row with blocks.";
        cout << "\n iv. Cleared lines will give you points and increase the game speed.";
        cout << "\n v. If the blocks stack up and reach the top, the game is over.";
    }
};
class shapes
{
public:

    string shape[shapesize];

    shapes()
    {
        for (int i = 0; i < shapesize; i++)
        {
            shape[i] = string(shapesize, emptyspace);
        }
    }
};

class tetromino : public shapes
{
public:
    tetromino() : shapes() {}
};


class tetris
{
public:
    int score;
    int level;
    char board[height][width];
    stack<tetromino> tetriminoStack;
    queue<tetromino> upcomingTetriminos;
    tetromino objects[7];
    tetromino currentobject;
    int posit1, posit2;
    tetris()
    {
        level = 1;
        for (int i = 0; i < height; i++)
        {
            for (int j = 0; j < width; j++)
            {
                board[i][j] = emptyspace;
            }
            score = 0;
        }


        objects[0].shape[0] = "    ";
        objects[0].shape[1] = "@@@@";
        objects[0].shape[2] = "    ";
        objects[0].shape[3] = "    ";

        objects[1].shape[0] = "  @ ";
        objects[1].shape[1] = "  @ ";
        objects[1].shape[2] = "  @ ";
        objects[1].shape[3] = "  @ ";

        objects[2].shape[0] = "    ";
        objects[2].shape[1] = " @@ ";
        objects[2].shape[2] = " @@ ";
        objects[2].shape[3] = "    ";

        objects[3].shape[0] = " @  ";
        objects[3].shape[1] = " @  ";
        objects[3].shape[2] = " @@ ";
        objects[3].shape[3] = "    ";

        objects[4].shape[0] = "    ";
        objects[4].shape[1] = "@@  ";
        objects[4].shape[2] = " @@ ";
        objects[4].shape[3] = "    ";

        objects[5].shape[0] = "  @ ";
        objects[5].shape[1] = "@@@ ";
        objects[5].shape[2] = "    ";
        objects[5].shape[3] = "    ";

        objects[6].shape[0] = " @  ";
        objects[6].shape[1] = "@@@ ";
        objects[6].shape[2] = "    ";
        objects[6].shape[3] = "    ";


        generateobject();
    }

    int getScore() const {
        return score;
    }

    int getPosit1() const {
        return posit1;
    }

    int getPosit2() const {
        return posit2;
    }
    const tetromino& getCurrentObject()
    {
        return currentobject;
    }
    const queue<tetromino>& getUpcomingTetriminos()
    {
        return upcomingTetriminos;
    }
    void popNextTetrimino()
    {
        if (!upcomingTetriminos.empty())
        {
            upcomingTetriminos.pop(); // Remove the next Tetrimino from the queue
        }
    }
    void generateobject()
    {
        int index = rand() % 7;
        currentobject = objects[index];
        upcomingTetriminos.push(currentobject);

        posit1 = width / 2 - shapesize / 2;
        posit2 = 0;
        if (collision())
        {
            cout << "GAME OVER!" << endl;

            exit(0);

        }
    }
    void increaselevel()
    {
        if (score >= level * 30) { // Increase level every 30 points
            level++;
        }
    }

    bool collision()
    {

        for (int i = 0; i < shapesize; i++)
        {
            for (int j = 0; j < shapesize; j++)
            {
                if (currentobject.shape[i][j] == block)
                {
                    int x = posit1 + j;
                    int y = posit2 + i;
                    if (x < 0 || x >= width || y >= height || (y >= 0 && board[y][x] == block))
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    bool checkmove(int newX, int newY, const string shape[shapesize])
    {

        for (int i = 0; i < shapesize; i++)
        {
            for (int j = 0; j < shapesize; j++)
            {
                if (shape[i][j] == block)
                {
                    int x = newX + j;
                    int y = newY + i;
                    if (x < 0 || x >= width || y >= height || (y >= 0 && board[y][x] == block))
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }


    void moveobject()
    {
        clearobject();

        if (checkmove(posit1, posit2 + 1, currentobject.shape))
        {
            posit2++;
        }
        else
        {
            placement();
            generateobject();
        }

        objectplace();
    }

    void placement()
    {
        for (int i = 0; i < shapesize; i++)
        {
            for (int j = 0; j < shapesize; j++)
            {
                if (currentobject.shape[i][j] == block)
                {
                    int x = posit1 + j;
                    int y = posit2 + i;
                    if (y >= 0)
                    {
                        board[y][x] = block;
                    }
                }
            }
        }
        int lineclear = eraseline();
        if (lineclear > 0) {
            score += (lineclear * 10);
            boards();
            increaselevel(); // Call the function to increase the level
        }
    }
    void clearobject()
    {

        for (int i = 0; i < shapesize; i++)
        {
            for (int j = 0; j < shapesize; j++)
            {
                if (currentobject.shape[i][j] == block)
                {
                    int x = posit1 + j;
                    int y = posit2 + i;
                    if (y >= 0)
                    {
                        board[y][x] = emptyspace;
                    }
                }
            }
        }
    }

    int eraseline()
    {
        int lineclear = 0;

        for (int i = height - 1; i >= 0; i--)
        {
            bool linecomplete = true;
            for (int j = 0; j < width; j++)
            {
                if (board[i][j] == emptyspace)
                {
                    linecomplete = false;
                    break;
                }
            }

            if (linecomplete)
            {

                for (int j = 0; j < width; j++)

                {
                    board[i][j] = emptyspace;
                }


                for (int k = i; k > 0; k--)
                {
                    for (int j = 0; j < width; j++)
                    {
                        board[k][j] = board[k - 1][j];
                    }
                }

                for (int j = 0; j < width; j++)
                {
                    board[0][j] = emptyspace;
                }

                lineclear++;
                i++;
            }
        }

        return lineclear;
    }
    void pushTetrimino(const tetromino t)
    {
        tetriminoStack.push(t);
    }

    void popTetrimino()
    {
        if (!tetriminoStack.empty())
        {
            tetriminoStack.pop();
        }
    }

    const tetromino& getTopTetrimino()
    {
        return tetriminoStack.top();
    }
    int returnlevel() {
        return level;
    }
    void boards()
    {
        system("cls");

        cout << "Score: " << getScore() << endl;
        cout << "Level: " << returnlevel() << endl;
    }

    void objectplace() {

        for (int i = 0; i < shapesize; i++)
        {
            for (int j = 0; j < shapesize; j++)
            {
                if (currentobject.shape[i][j] == block)
                {
                    int x = posit1 + j;
                    int y = posit2 + i;
                    if (y >= 0)
                    {
                        board[y][x] = block;
                    }
                }
            }
        }
    }

};
class movements : public tetris, public tetromino
{
public:
    tetris game;
    int score = game.getScore();

    void moverotate()
    {

        clearobject();
        tetromino newtetromino;
        for (int i = 0; i < shapesize; i++)
        {
            for (int j = 0; j < shapesize; j++)
            {
                newtetromino.shape[i][j] = currentobject.shape[shapesize - j - 1][i];
            }
        }
        if (checkmove(posit1, posit2, newtetromino.shape))
        {
            currentobject = newtetromino;
        }


        objectplace();
    }

    void moveright()
    {

        clearobject();

        if (checkmove(posit1 + 1, posit2, currentobject.shape))
        {
            posit1++;
        }


        objectplace();
    }

    void moveleft()
    {

        clearobject();

        if (checkmove(posit1 - 1, posit2, currentobject.shape))
        {
            posit1--;
        }


        objectplace();
    }
    void play()
    {
        while (true)
        {
            if (_kbhit())
            {
                char key = _getch();
                switch (key)
                {
                case 'a':
                    moveleft();
                    break;
                case 'd':
                    moveright();
                    break;
                case 'w':
                    moverotate();
                    break;
                case 's':
                    moveobject();
                    break;
                }
            }
            else
            {
                moveobject();
            }

            boards();
        }
    }
};
class TetrisSFML
{
private:
    const float blockSize = 30.0f; // Size of each block in pixels
    sf::RenderWindow window;
    movements tetrisMovements; // Instance of movements class
    tetris a;
public:
    TetrisSFML() : tetrisMovements()
    {
        window.create(sf::VideoMode(400, 600), "SFML Tetris");
        window.setFramerateLimit(7);
    }

    void run()
    {
        while (window.isOpen())
        {
            handleEvents();
            update();
            render();

        }
    }

private:
    void handleEvents()
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            else if (event.type == sf::Event::KeyPressed)
            {
                if (event.key.code == sf::Keyboard::A)
                    tetrisMovements.moveleft();
                else if (event.key.code == sf::Keyboard::D)
                    tetrisMovements.moveright();
                else if (event.key.code == sf::Keyboard::W)
                    tetrisMovements.moverotate();
                else if (event.key.code == sf::Keyboard::S)
                    tetrisMovements.moveobject();
            }
        }
    }
    void update()
    {
        tetrisMovements.moveobject();
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
        {
            tetrisMovements.moveleft();
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
        {
            tetrisMovements.moveright();
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
        {
            tetrisMovements.moverotate();
        }
    }

    void render()
    {
        window.clear(sf::Color::Black);
        sf::RectangleShape boardBackground(sf::Vector2f(width * blockSize, height * blockSize));
        boardBackground.setFillColor(sf::Color::Black);
        window.draw(boardBackground);
        for (int i = 0; i < height; i++)
        {
            for (int j = 0; j < width; j++)
            {
                if (tetrisMovements.board[i][j] == block)
                {

                    sf::RectangleShape blockShape(sf::Vector2f(blockSize, blockSize));
                    blockShape.setFillColor(sf::Color::Yellow);
                    blockShape.setPosition(j * blockSize, i * blockSize);
                    window.draw(blockShape);
                }
            }
        }
        window.display();
    }
};
void centerOutput(const std::string& text, int width) {
    int padding = (width - text.length()) / 2;
    if (padding > 0) {
        for (int i = 0; i < padding; ++i) {
            std::cout << ' ';
        }
        std::cout << text << std::endl;
    }
    else {
        std::cout << text << std::endl;
    }
}
int main()
{
    information a;
    const int consoleWidth = 110;
    cout << "\033[1;36m";
    centerOutput(" || LOGIN PAGE || ", consoleWidth);
    centerOutput("ENTER YOUR information: ", consoleWidth);
    int x;
    centerOutput("-----------------------", consoleWidth);
    centerOutput("||1. Register        ||", consoleWidth);
    centerOutput("||2. Login           ||", consoleWidth);
    centerOutput("||Enter your choice: || ", consoleWidth);
    centerOutput("-----------------------", consoleWidth);

    cin >> x;
    switch (x)
    {
    case 1:
        a.rejisteruser();
        break;
    case 2:
        a.login();
        break;
    default:
        centerOutput("Invalid choice.", consoleWidth);
        break;
    }
    a.playersname();
    system("cls");
    int choice;
    tetrisgame tet;
    while (true)
    {
        tet.name();
        centerOutput("\n\n\n1. Start the game", consoleWidth);
        centerOutput("\n2. Instructions", consoleWidth);
        centerOutput("\n3. Rules", consoleWidth);
        centerOutput("\n4. Exit", consoleWidth);
        centerOutput("\nEnter your choice: ", consoleWidth);
        cin >> choice;
        TetrisSFML tetrisSFML;
        switch (choice)
        {
        case 1:

            system("cls");
            tetrisSFML.run();
            break;
        case 2:

            system("cls");
            tet.details();
            break;
        case 3:

            system("cls");

            tet.rules();
            break;
        case 4:

            exit(0);
        default:
            centerOutput("Invalid choice. Please try again.\n", consoleWidth);
            break;
        }

        cout << endl;
    }

    cout << "Press any key to exit";

    return 0;
}